import Image from 'next/image'
import FarstPage from "@/components/FarstPage";


export default function Home() {
  return (
    <>
     <FarstPage />
    </>
  )
}
